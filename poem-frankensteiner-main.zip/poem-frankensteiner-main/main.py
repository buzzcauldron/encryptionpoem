def main():
    print("Hello from poem-frankensteiner!")


if __name__ == "__main__":
    main()
